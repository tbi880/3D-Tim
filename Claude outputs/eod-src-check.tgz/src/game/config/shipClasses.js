import { FACTION } from './gameConfig.js';

/**
 * Ship class table. Adding a ship means adding one entry here, a model with the same
 * `model` id (see tools/game-models/build_models.py and scene/models/ShipModel.jsx) and
 * its name in both i18n files.
 *
 * Sizes follow EVE-style tiers, in metres: fighters ~15-30, corvette 130, frigate 280,
 * cruiser 520, the Dawnbreaker 1400, the Eclipse 3400.
 *
 * behavior:
 *   'player'  - flown by the human (systems/playerFlight.js)
 *   'fighter' - attack run / break away loop
 *   'bomber'  - approaches capital ships, launches torpedoes, retreats, repeats
 *   'capital' - ship of the line that keeps a stand-off distance; fights with turrets
 *   'module'  - destructible part mounted on a parent ship (generators, turrets, reactors)
 *   'static'  - does nothing (stations, wrecks, the log buoy)
 *
 * kind: 'fighter' | 'capital' | 'station' | 'module' | 'object' - what others treat it as.
 *
 * Hit shape: `radius` alone is a sphere (small craft, modules). Bigger ships use boxes that
 * turn with the ship: `halfExtents` [x, y, z] is one box around the centre; `hitBoxes`
 * [[cx, cy, cz, hx, hy, hz], ...] is several, for hulls a single box would wrap too
 * loosely (the Eclipse's blades, the Forge's dock). Boxes hug the solid hull and leave out
 * antennae and fins, so near misses do not count and modules mounted on the hull stay reachable.
 * A player ship with boxes also rams and is rammed by them (systems/collisions.js); its
 * `radius` then only places the camera and the gun muzzles. `shieldExtents` [x, y, z]
 * optionally sets the half-size of the shield shell, if the default (boxes x 1.45) fits badly.
 *
 * ai.prefers lists target kinds in order of preference
 * ('player', 'bomber', 'fighter', 'capital').
 */
export const SHIP_CLASSES = Object.freeze({
    // ---- Dawn fleet ---------------------------------------------------------------------
    // ---- Player ships (config/playerShips.js) ------------------------------------------------
    // Each is tuned to what its model looks like. Two extra fields shape them:
    //   handling     - multipliers on the baseline flight model (gameConfig PLAYER): turn (all
    //                  three axes), acceleration, boostDuration (how long the afterburner tank
    //                  lasts) and boostMultiplier (afterburner top speed)
    //   weaponDamage - multiplier on beam and torpedo damage
    //   weaponRange  - multiplier on beam reach (1300 m) and torpedo flight time (about 5 km)
    // `radius` is the hit sphere: bigger hulls are easier to hit and to scrape on rocks.
    // Models: MODEL_OVERRIDES in scene/models/ShipModel.jsx.
    kestrel: {
        // X-wing: the four-engine fleet workhorse, the yardstick the others are measured against.
        nameKey: 'ship.kestrel', faction: FACTION.DAWN, behavior: 'player', kind: 'fighter',
        model: 'kestrel', radius: 9,
        hull: 130, shield: 120, shieldRegen: 12, shieldDelay: 3.5,
        maxSpeed: 150, turnRate: 1.2, acceleration: 110,
        weaponRange: 1,
        weapons: ['playerBeam', 'playerTorpedo'],
    },
    swift: {
        // Alien spaceship: a compact predator built to turn. Tears round inside anything, a fierce
        // first bite; almost no armour, and its organic shield is thin but grows back at once.
        nameKey: 'ship.swift', faction: FACTION.DAWN, behavior: 'player', kind: 'fighter',
        model: 'swift', radius: 8,
        hull: 95, shield: 85, shieldRegen: 22, shieldDelay: 2,
        maxSpeed: 175, turnRate: 1.2, acceleration: 110,
        handling: { turn: 1.75, acceleration: 1.3, boostDuration: 0.7, boostMultiplier: 1 },
        weaponDamage: 1,
        weaponRange: 0.75,
        weapons: ['playerBeam', 'playerTorpedo'],
    },
    shrike: {
        // Archont: a long gun-ship - all cannon and engine. Hits harder than anything its size and
        // is quick in a straight line, but swings its length round slowly and has barely a shield.
        nameKey: 'ship.shrike', faction: FACTION.DAWN, behavior: 'player', kind: 'fighter',
        model: 'shrike', radius: 10,
        hull: 130, shield: 50, shieldRegen: 7, shieldDelay: 4.5,
        maxSpeed: 162, turnRate: 1.2, acceleration: 110,
        handling: { turn: 0.68, acceleration: 1, boostDuration: 1, boostMultiplier: 1.05 },
        weaponDamage: 1.65,
        weaponRange: 1.5,
        weapons: ['playerBeam', 'playerTorpedo'],
    },
    bulwark: {
        // Vigilant: a destroyer with a fighter's crew. Heaviest shields, plate and guns in the
        // fleet, with the longest reach, but by far the slowest: under half the Kestrel's speed and
        // a quarter of its turn rate, so it fights from where it is and lets targets come into its
        // arc. Big tanks give it the longest afterburner burn in the fleet. At 39 m it is the biggest
        // target in the sky.
        nameKey: 'ship.bulwark', faction: FACTION.DAWN, behavior: 'player', kind: 'fighter',
        model: 'bulwark', radius: 19,
        // Measured from vigilant-transformed.glb as ShipModel places it: a 39 m hull that narrows
        // from 8.5 m across the stern to under 3 m at the bow. Nose towards -z.
        hitBoxes: [[0, -0.6, -13.5, 2.15, 1.9, 6], [0, -0.1, -1.5, 2.8, 2.75, 6], [0, 0.05, 12, 4.3, 3, 7.5]],
        // The smallest ellipsoid that clears every vertex by about 2 m.
        shieldExtents: [7.3, 5.8, 24.6],
        hull: 330, shield: 310, shieldRegen: 24, shieldDelay: 3,
        maxSpeed: 66, turnRate: 1.2, acceleration: 110,
        handling: { turn: 0.3, acceleration: 0.34, boostDuration: 3.2, boostMultiplier: 1.25 },
        weaponDamage: 1.85,
        weaponRange: 1.7,
        weapons: ['playerBeam', 'playerTorpedo'],
    },
    peregrine: {
        // Spaceship: a flat, wide racer that is mostly engine grilles. Fastest in a line, off the
        // mark and on the afterburner, with a good shield to run behind; light guns, paper hull.
        nameKey: 'ship.peregrine', faction: FACTION.DAWN, behavior: 'player', kind: 'fighter',
        model: 'peregrine', radius: 9,
        hull: 110, shield: 135, shieldRegen: 15, shieldDelay: 3,
        maxSpeed: 215, turnRate: 1.2, acceleration: 110,
        handling: { turn: 1.2, acceleration: 1.7, boostDuration: 1.7, boostMultiplier: 1.2 },
        weaponDamage: 0.92,
        weaponRange: 1.1,
        weapons: ['playerBeam', 'playerTorpedo'],
    },
    dawnbreaker: {
        nameKey: 'ship.dawnbreaker', faction: FACTION.DAWN, behavior: 'capital', kind: 'capital',
        model: 'dawnbreaker', radius: 640, halfExtents: [215, 80, 640],
        hull: 3000, shield: 0, shieldRegen: 14, shieldDelay: 8,
        maxSpeed: 0, turnRate: 0, acceleration: 0,
        weapons: ['pointDefenseBeam', 'pointDefenseBeam', 'pointDefenseBeam'],
        ai: { mode: 'hold' },
    },
    harrier: {
        nameKey: 'ship.harrier', faction: FACTION.DAWN, behavior: 'capital', kind: 'capital',
        model: 'harrier', radius: 140,
        hitBoxes: [[0, 0, 0, 30, 22, 135], [-68, 10, 75, 12, 11, 66], [68, 10, 75, 12, 11, 66]],
        hull: 1400, shield: 340, shieldRegen: 9, shieldDelay: 6,
        maxSpeed: 55, turnRate: 0.28, acceleration: 16,
        weapons: ['frigateBeam', 'frigateBeam', 'frigateTorpedo'],
        ai: { standoff: 1300, prefers: ['capital', 'fighter'] },
    },
    dart: {
        nameKey: 'ship.dart', faction: FACTION.DAWN, behavior: 'fighter', kind: 'fighter',
        model: 'dart', radius: 7,
        hull: 60, shield: 40, shieldRegen: 5, shieldDelay: 5,
        maxSpeed: 140, turnRate: 1.5, acceleration: 90,
        weapons: ['dartBolt'],
        ai: { attackRange: 800, breakDistance: 130, prefers: ['bomber', 'fighter', 'capital'] },
    },
    buoy: {
        nameKey: 'ship.buoy', faction: FACTION.NEUTRAL, behavior: 'static', kind: 'object',
        model: 'buoy', radius: 12,
        hull: 1, shield: 0, shieldRegen: 0, shieldDelay: 0,
        maxSpeed: 0, turnRate: 0, acceleration: 0,
        weapons: [], invulnerable: true, targetable: false,
    },
    wreck: {
        nameKey: 'ship.wreck', faction: FACTION.NEUTRAL, behavior: 'static', kind: 'object',
        model: 'wreck', radius: 95, halfExtents: [28, 18, 92],
        hull: 1, shield: 0, shieldRegen: 0, shieldDelay: 0,
        maxSpeed: 0, turnRate: 0, acceleration: 0,
        weapons: [], invulnerable: true, targetable: false,
    },

    // ---- Umbra --------------------------------------------------------------------------
    drone: {
        nameKey: 'ship.drone', faction: FACTION.UMBRA, behavior: 'fighter', kind: 'fighter',
        model: 'drone', radius: 6.5,
        hull: 39, shield: 0, shieldRegen: 0, shieldDelay: 0,
        maxSpeed: 140, turnRate: 1.59, acceleration: 92,
        weapons: ['droneBolt'],
        ai: { attackRange: 650, breakDistance: 110, prefers: ['player', 'fighter', 'capital'] },
    },
    raider: {
        nameKey: 'ship.raider', faction: FACTION.UMBRA, behavior: 'fighter', kind: 'fighter',
        model: 'raider', radius: 9,
        hull: 62, shield: 47, shieldRegen: 7, shieldDelay: 4,
        maxSpeed: 130, turnRate: 1.26, acceleration: 76,
        weapons: ['raiderBolt'],
        ai: { attackRange: 760, breakDistance: 140, prefers: ['player', 'fighter', 'capital'] },
    },
    lancer: {
        nameKey: 'ship.lancer', faction: FACTION.UMBRA, behavior: 'bomber', kind: 'fighter',
        model: 'lancer', radius: 12,
        hull: 75, shield: 36, shieldRegen: 5, shieldDelay: 4.5,
        maxSpeed: 108, turnRate: 0.93, acceleration: 54,
        weapons: ['lancerTorpedo'],
        ai: { prefers: ['capital'], retreatTime: 7 },
    },
    corvette: {
        nameKey: 'ship.corvette', faction: FACTION.UMBRA, behavior: 'capital', kind: 'capital',
        model: 'corvette', radius: 65, halfExtents: [26, 12, 62],
        hull: 312, shield: 195, shieldRegen: 10, shieldDelay: 5,
        maxSpeed: 85, turnRate: 0.5, acceleration: 22,
        weapons: ['turretBolt', 'turretBolt'],
        ai: { standoff: 700, prefers: ['player', 'capital'] },
    },
    warden: {
        nameKey: 'ship.warden', faction: FACTION.UMBRA, behavior: 'capital', kind: 'capital',
        model: 'warden', radius: 260,
        hitBoxes: [[0, -11, 65, 43, 38, 190], [-50, -11, -95, 18, 25, 135], [50, -11, -95, 18, 25, 135]],
        hull: 598, shield: 364, shieldRegen: 12, shieldDelay: 5,
        maxSpeed: 40, turnRate: 0.14, acceleration: 9,
        weapons: ['turretBolt', 'turretBolt', 'cruiserBeam'],
        ai: { standoff: 1400, prefers: ['capital', 'player'] },
    },
    eclipse: {
        nameKey: 'ship.eclipse', faction: FACTION.UMBRA, behavior: 'capital', kind: 'capital',
        model: 'eclipse', radius: 1700,
        // Aft hull, fore hull, the two blades, the citadel.
        hitBoxes: [
            [0, -147, 722, 543, 388, 920], [0, -147, -586, 330, 252, 388],
            [-795, -147, -199, 155, 349, 1017], [795, -147, -199, 155, 349, 1017],
            [0, 483, 722, 213, 252, 368],
        ],
        hull: 4000, shield: 0, shieldRegen: 0, shieldDelay: 0,
        maxSpeed: 0, turnRate: 0, acceleration: 0,
        // Its guns are separate, destructible cannon modules (see spawnEclipse in story/campaign.js).
        weapons: ['eclipseLance', 'cruiserBeam'],
        ai: { mode: 'hold', prefers: ['capital'] },
    },
    shieldGenerator: {
        nameKey: 'ship.shieldGenerator', faction: FACTION.UMBRA, behavior: 'module', kind: 'module',
        model: 'shieldGenerator', radius: 75,
        hull: 230, shield: 0, shieldRegen: 0, shieldDelay: 0,
        maxSpeed: 0, turnRate: 0, acceleration: 0,
        weapons: [],
    },
    forge: {
        nameKey: 'ship.forge', faction: FACTION.UMBRA, behavior: 'static', kind: 'station',
        model: 'forge', radius: 1500,
        // The keel dock and the habitat drum; the slipway arches can be flown through.
        hitBoxes: [[0, 0, -290, 175, 155, 1210], [0, 0, 1235, 350, 330, 270]],
        hull: 1, shield: 0, shieldRegen: 0, shieldDelay: 0,
        maxSpeed: 0, turnRate: 0, acceleration: 0,
        weapons: [], invulnerable: true, targetable: false,
    },
    tractorEmitter: {
        nameKey: 'ship.tractorEmitter', faction: FACTION.UMBRA, behavior: 'module', kind: 'module',
        model: 'tractorEmitter', radius: 55,
        hull: 200, shield: 0, shieldRegen: 0, shieldDelay: 0,
        maxSpeed: 0, turnRate: 0, acceleration: 0,
        weapons: [],
    },
    reactor: {
        nameKey: 'ship.reactor', faction: FACTION.UMBRA, behavior: 'module', kind: 'module',
        model: 'reactor', radius: 85,
        hull: 520, shield: 0, shieldRegen: 0, shieldDelay: 0,
        maxSpeed: 0, turnRate: 0, acceleration: 0,
        weapons: [],
    },
    eclipseCannon: {
        // A gun battery bolted to the Eclipse. Short-ranged for its size: stay outside its reach or kill it.
        nameKey: 'ship.eclipseCannon', faction: FACTION.UMBRA, behavior: 'module', kind: 'module',
        model: 'stationTurret', radius: 42,
        // One torpedo's worth: they can be picked off from outside their own range.
        hull: 220, shield: 0, shieldRegen: 0, shieldDelay: 0,
        maxSpeed: 0, turnRate: 0, acceleration: 0,
        weapons: ['eclipseCannon'],
    },
    stationTurret: {
        nameKey: 'ship.stationTurret', faction: FACTION.UMBRA, behavior: 'module', kind: 'module',
        model: 'stationTurret', radius: 42,
        hull: 150, shield: 0, shieldRegen: 0, shieldDelay: 0,
        maxSpeed: 0, turnRate: 0, acceleration: 0,
        weapons: ['turretBolt'],
    },
});
