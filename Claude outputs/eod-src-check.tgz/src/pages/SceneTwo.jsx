import { getEngineeringHasBeenAccessed, getRootAccess, getShipHangerHasBeenAccessed } from './Status';
import StrangerStar from '../modelComponents/StrangerStar';
import ShipInside from '../modelComponents/ShipInside';
import Galaxy from '../modelComponents/Galaxy';
import TextTitle from '../modelComponents/TextTitle';
import InfoScreenDisplay from '../modelComponents/InfoScreenDisplay';
import SingleLoadManager from '../modelComponents/SingleLoadManager';
import Button from '../modelComponents/Button';
import ViewPort from '../modelComponents/ViewPort';
import StreamMusic from '../modelComponents/StreamMusic';
import Robots from '../modelComponents/Robot';
import { Suspense, useState, useEffect, useContext } from 'react';
import { useComposerMultisampling } from '../hooks/useComposerMultisampling';
import PreloadAssets from '../modelComponents/PreloadAssets';
import { editable as e, PerspectiveCamera } from '@theatre/r3f'
import { bucketURL, stageOfENV } from '../Settings';
import Loading from '../modelComponents/Loading';
import { Environment, useGLTF } from '@react-three/drei';
import Loader from './Loader';
import { Perf } from 'r3f-perf';
import { useComponentDisplayManager } from '../hooks/useComponentDisplayManager';
import { useAudioElement } from '../hooks/useAudioElement';
import { useSequenceUnloadSceneChecker } from '../hooks/useSequenceUnloadSceneChecker';
import { TaskBoardContentContext } from '../sharedContexts/TaskBoardContentProvider';
import { GlobalNotificationContext } from '../sharedContexts/GlobalNotificationProvider';
import { SheetSequencePlayControlContext } from '../sharedContexts/SheetSequencePlayControlProvider';
import { useSequenceAutoSave, getResumePosition, getNextClickablePoint, getJumpPointResumePosition, clearResumePositionsIfNavigated } from '../hooks/useSequenceAutoSave';
import { Bloom, BrightnessContrast, ChromaticAberration, DepthOfField, Glitch, ToneMapping, Vignette } from "@react-three/postprocessing";
import ManagedEffectComposer from '../modelComponents/ManagedEffectComposer';
import { createSuspenseGate, SuspenseGate } from '../utils/createSuspenseGate';

const SCENE2_CLICKABLE_POINTS = [1, 1.5, 2, 2.5, 22.5, 33, 68, 86];
const SCENE2_JUMP_POINTS_MAP = [[33, 38], [68, 72], [86, 96]];


function SceneTwo({ scene2Sheet, scene2Project, startPoint, unloadPoints, onSequencePass, isPortraitPhoneScreen }) {
    const composerMultisampling = useComposerMultisampling();
    const screenIntro = "You finally awaken, chief designer! Our ship is about to enter the black hole ahead of us. The ship is damaged quite severe due to the strong gravitational force. As AI, we cannot change the course of the ship because the first captain, Tim Bi, set it up millennia ago. Additionally, we have been blocked from answering the questions to unlock the captain's chamber. We need your help to find the answers to the root access questions so we can alter the ship's course or initiate an emergency stop. Please follow me to the bridge. Let's start by checking the structure of the ship first. This will probably help you to rewind your memory about the ship.";
    const musicUrl = bucketURL + 'music/bgm2.mp3';
    const audioElement = useAudioElement(musicUrl);
    useSequenceUnloadSceneChecker(scene2Sheet.sequence, unloadPoints, onSequencePass);
    useSequenceAutoSave('scene2', scene2Sheet.sequence);
    const { taskBoardContent, setTaskBoardContent } = useContext(TaskBoardContentContext);
    const { messageApi } = useContext(GlobalNotificationContext);
    const { isSequencePlaying, setIsSequencePlaying, rate, setRate, targetPosition, setTargetPosition, playOnce } = useContext(SheetSequencePlayControlContext);
    const [gate] = useState(() => createSuspenseGate());


    const [showComponents, toggleComponentDisplay] = useComponentDisplayManager({
        loadingComponents: {
            openEyes: true,
            preloadAssets: true,
            shipInside: true,
            robotIntro: true,
            viewPortIntro: true,
            screenIntro: true,
            buttonForGOTOShipHangar: false,
            buttonForGOTOEngineering: false,
            buttonForGOTOCaptainsChamber: false,
            textTitleGetROOTACCESS: false,
            viewPortShipHanger: false,
            loadingForShipHanger: false,
            viewPortEngineering: false,
            loadingForEngineering: false,
            viewPortTimsChamber: false,
            loadingForTimsChamber: false
        }, initialComponents: {
            openEyes: true,
            preloadAssets: false,
            shipInside: true,
            robotIntro: true,
            viewPortIntro: true,
            screenIntro: true,
            buttonForGOTOShipHangar: false,
            buttonForGOTOEngineering: false,
            buttonForGOTOCaptainsChamber: false,
            textTitleGetROOTACCESS: false,
            viewPortShipHanger: false,
            loadingForShipHanger: false,
            viewPortEngineering: false,
            loadingForEngineering: false,
            viewPortTimsChamber: false,
            loadingForTimsChamber: false
        }
    });


    useEffect(() => {
        useGLTF.preload(bucketURL + 'loading.glb');

        scene2Project.ready.then(() => {
            clearResumePositionsIfNavigated();
            const savedPosition = getResumePosition('scene2');
            if (savedPosition !== null && savedPosition > 0) {
                const jumpPoint = getJumpPointResumePosition(savedPosition, SCENE2_JUMP_POINTS_MAP);
                if (jumpPoint !== null) {
                    scene2Sheet.sequence.position = jumpPoint;
                } else {
                    scene2Sheet.sequence.position = savedPosition;
                    const nextPoint = getNextClickablePoint(savedPosition, SCENE2_CLICKABLE_POINTS);
                    if (nextPoint !== null) {
                        playOnce({ sequence: scene2Sheet.sequence, range: [savedPosition, nextPoint] });
                    }
                }
            } else if (startPoint && startPoint != 0) {
                playOnce({ sequence: scene2Sheet.sequence, range: [startPoint, startPoint + 0.5] });
            }
        });
    }, []);





    const [taskBoardContentMap, setTaskBoardContentMap] = useState({
        0: "I am now awaken in the ship. What happened to the ship? Let me find out by asking the AI. ( Click on the AI to start the conversation )",
        1: "Okay, so the ship is in danger... I need to get the command chamber as quickly as possible to save the ship. In order to do so, I need to find the root access first, since I am the only one on ship know the early life of the mighty captain Tim, that's why i am here. Let me go to the bridge to check the structure of the ship first, then decide where to go next.",
        2: "Seems the ship is in a bad shape, can't handle too long, maybe just a few hours left. Let me decide where should i go next. ( Click on one of the buttons to decide where to go next )",
        3: "Let me go to the ship hanger , maybe I can find some information relate to Tim's early experience there.",
        4: "Let me go to the engineering department, maybe I can find some information relate to Tim's early projects there.",
        5: "Let me go to Tim's chamber finally, to save the ship. ( strongly recommend to use the PC to view this part, some of the models are too heavy to load on the phone )",
    });

    useEffect(() => {
        setTaskBoardContent(new Array(taskBoardContentMap[0]));
    }, []);

    return (
        <>
            <Suspense fallback={<Loader isIntroNeeded={false} extraContent={["You will see some options", "Where you want to go depends on what you want to know about me", "My journey in tech or my previous work experience.", "or you want to meet me in person in my command chamber"]} onFadeComplete={() => gate.resolve()} />}>
                {stageOfENV != "prod" && !isPortraitPhoneScreen && <Perf position={"bottom-right"} openByDefault showGraph />}

                {showComponents.preloadAssets && <PreloadAssets />}
                <SuspenseGate gate={gate} />

                {audioElement && <StreamMusic audioElement={audioElement} sequence={scene2Sheet.sequence} startPoint={1} />}
                <PerspectiveCamera theatreKey="FirstPersonCamera" makeDefault position={[498, -19, -61]} rotation={[0, 1.55, 0]} fov={75} near={0.01} />

                <color attach='background' args={['black']} />

                <Galaxy />
                <StrangerStar />

                <Environment
                    files={bucketURL + 'pic/warehouse.hdr'}
                    resolution={1024}
                    intensity={0.5}
                    background={false}
                    backgroundIntensity={0}
                    environmentIntensity={1}
                />
                <ShipInside sequence={scene2Sheet.sequence} onSequencePass={() => toggleComponentDisplay('shipInside')} />
                {showComponents.viewPortIntro && <ViewPort screenTitle="Intro" position={[613, -15.5, -106]} rotation={[0, 0, 0]} sequence={scene2Sheet.sequence} stopPoint={1} unloadPoint={1} onSequencePass={() => toggleComponentDisplay('viewPortIntro')} />}
                {showComponents.robotIntro && <Robots title="Intro" position={[613, -15.5, -106]} rotation={[0, 0, 0]} sequence={scene2Sheet.sequence} onSequencePass={() => toggleComponentDisplay('robotIntro')} />}
                {showComponents.screenIntro && <InfoScreenDisplay title="Conversation" content={screenIntro} sequence={scene2Sheet.sequence} stopPoints={[1.5, 2, 2.5, 22.5]} loadPoints={isPortraitPhoneScreen ? [0, 1.5, 2, 2.5] : [0, 1, 1.5, 2]} unloadPoints={[2, 2.5, 3, 3.5]} onSequencePass={() => toggleComponentDisplay("screenIntro")} />}

                <SingleLoadManager loadPoint={22} sequence={scene2Sheet.sequence} onSequencePass={() => toggleComponentDisplay('textTitleGetROOTACCESS')} />
                {showComponents.textTitleGetROOTACCESS && <TextTitle text="Where to get the ROOT ACCESS?" color="#99CCFF" size={1} sequence={scene2Sheet.sequence} unloadPoint={24} onSequencePass={() => toggleComponentDisplay('textTitleGetROOTACCESS')} />}
                <SingleLoadManager loadPoint={22} sequence={scene2Sheet.sequence} onSequencePass={() => toggleComponentDisplay('buttonForGOTOShipHangar')} />
                {showComponents.buttonForGOTOShipHangar && !(getShipHangerHasBeenAccessed()) && <Button title={"To the ship hanger"} position={[490, -23.5, -60]} rotation={[0, 0, 0]} clickablePoint={22.5} jumpToPoint={22.5} stopPoint={33} unloadPoint={24} sequence={scene2Sheet.sequence} onSequencePass={() => toggleComponentDisplay('buttonForGOTOShipHangar')} additionalOnClickCallback={() => {
                    setTaskBoardContent(prev => [...prev, taskBoardContentMap[3]]);
                }} />}
                <SingleLoadManager loadPoint={22} sequence={scene2Sheet.sequence} onSequencePass={() => toggleComponentDisplay('buttonForGOTOEngineering')} />
                {showComponents.buttonForGOTOEngineering && !(getEngineeringHasBeenAccessed()) && <Button title={"To the engineering"} position={[490, -23.5, -60]} rotation={[0, 0, 0]} clickablePoint={22.5} IsPreJump={true} jumpToPoint={39} stopPoint={68} unloadPoint={24} sequence={scene2Sheet.sequence} onSequencePass={() => toggleComponentDisplay('buttonForGOTOEngineering')} additionalOnClickCallback={() => {
                    setTaskBoardContent(prev => [...prev, taskBoardContentMap[4]]);
                }} />}
                <SingleLoadManager loadPoint={22} sequence={scene2Sheet.sequence} onSequencePass={() => toggleComponentDisplay('buttonForGOTOCaptainsChamber')} />
                {showComponents.buttonForGOTOCaptainsChamber && <Button title={"To Tim's chamber"} position={[490, -23.5, -60]} rotation={[0, 0, 0]} clickablePoint={22.5} IsPreJump={true} jumpToPoint={73.5} stopPoint={86} unloadPoint={24} sequence={scene2Sheet.sequence} onSequencePass={() => toggleComponentDisplay('buttonForGOTOCaptainsChamber')} alertAndNoPlay={!getRootAccess()} alertMessage={"Please come back later when you have the access. You are not authorized to go there yet! "} />}


                {/*
 这里开始是去ship hanger的部分
 */}
                <SingleLoadManager loadPoint={33} sequence={scene2Sheet.sequence} onSequencePass={() => toggleComponentDisplay('viewPortShipHanger')} />
                {showComponents.viewPortShipHanger && <ViewPort screenTitle="Ship Hanger" position={[470, -21, -5.5]} rotation={[0, -1.57, 0]} sequence={scene2Sheet.sequence} stopPoint={38} unloadPoint={35} onSequencePass={() => toggleComponentDisplay('viewPortShipHanger')} isSetNextScene={true} nextScene={"sceneThree"} nextSceneStartPoint={0} />}
                <SingleLoadManager loadPoint={35} sequence={scene2Sheet.sequence} onSequencePass={() => toggleComponentDisplay('loadingForShipHanger')} />
                {showComponents.loadingForShipHanger && <Loading title="ship hanger" lines={["Connecting", "to Tim's", "namespace"]} position={[470, -21, -5.5]} rotation={[0, 0, 0]} sequence={scene2Sheet.sequence} unloadPoint={38.5} onSequencePass={() => toggleComponentDisplay('loadingForShipHanger')} />}


                {/*
 这里开始是去Engineering的部分
 */}
                <SingleLoadManager loadPoint={63} sequence={scene2Sheet.sequence} onSequencePass={() => toggleComponentDisplay('viewPortEngineering')} />
                {showComponents.viewPortEngineering && <ViewPort screenTitle="EngineeringDept" position={[609, -20.8, -15.75]} rotation={[0, 0, 0]} sequence={scene2Sheet.sequence} stopPoint={72} unloadPoint={69} onSequencePass={() => toggleComponentDisplay('viewPortEngineering')} isSetNextScene={true} nextScene={"sceneFour"} nextSceneStartPoint={0} />}
                <SingleLoadManager loadPoint={70} sequence={scene2Sheet.sequence} onSequencePass={() => toggleComponentDisplay('loadingForEngineering')} />
                {showComponents.loadingForEngineering && <Loading THkey="Engineering" title="Engineering" lines={["Connecting ", "to Tim's ", "namespace "]} position={[609, -20.8, -15.75]} rotation={[0, 4.68, 0]} sequence={scene2Sheet.sequence} unloadPoint={73} onSequencePass={() => toggleComponentDisplay('loadingForEngineering')} textTitleVersion={2} />}


                {/*
 这里开始是去Tim's chamber的部分
 */}
                <SingleLoadManager loadPoint={83} sequence={scene2Sheet.sequence} onSequencePass={() => toggleComponentDisplay('viewPortTimsChamber')} />
                {showComponents.viewPortTimsChamber && <ViewPort screenTitle="TimsChamber" position={[548, -17.85, -26.15]} rotation={[0, 11, 0]} sequence={scene2Sheet.sequence} stopPoint={96} unloadPoint={90} onSequencePass={() => toggleComponentDisplay('viewPortTimsChamber')} isSetNextScene={true} nextScene={"sceneFive"} nextSceneStartPoint={0} />}
                <SingleLoadManager loadPoint={93} sequence={scene2Sheet.sequence} onSequencePass={() => toggleComponentDisplay('loadingForTimsChamber')} />
                {showComponents.loadingForTimsChamber && <Loading THkey="TimsChamber" title="TimsChamber" lines={["Authenticating ", "access to ", "Tim's chamber "]} position={[560.75, 5.25, -22.5]} rotation={[0, 9.45, 0]} sequence={scene2Sheet.sequence} unloadPoint={96.5} onSequencePass={() => toggleComponentDisplay('loadingForTimsChamber')} textTitleVersion={2} />}


                <SingleLoadManager
                    loadPoint={4}
                    sequence={scene2Sheet.sequence}
                    onSequencePass={() => {
                        setTaskBoardContent(prev => [...prev, taskBoardContentMap[1]]);
                    }}
                />

                <SingleLoadManager
                    loadPoint={22.5}
                    sequence={scene2Sheet.sequence}
                    onSequencePass={() => {
                        setTaskBoardContent(prev => [...prev, taskBoardContentMap[2]]);
                    }}
                />
                <SingleLoadManager
                    loadPoint={75}
                    sequence={scene2Sheet.sequence}
                    onSequencePass={() => {
                        setTaskBoardContent(prev => [...prev, taskBoardContentMap[5]]);
                    }}
                />

                <SingleLoadManager loadPoint={1} sequence={scene2Sheet.sequence} onSequencePass={() => toggleComponentDisplay('openEyes')} />
                <ManagedEffectComposer enableNormalPass multisampling={composerMultisampling}>
                    {showComponents.openEyes && <>
                        <DepthOfField focusDistance={0.03} focalLength={0.1} bokehScale={5} />
                        <ChromaticAberration offset={[0.002, 0.002]} />
                        <Vignette eskil={false} offset={0.25} darkness={1.5} />
                    </>}

                    {(!showComponents.openEyes) && <>
                        <BrightnessContrast brightness={0.1} />
                        <Glitch isActive={true} delay={15} duration={0.5} />
                        <Bloom intensity={0.4} luminanceThreshold={0.3} />
                        <ToneMapping adaptive />
                        <Vignette eskil={false} offset={0.1} darkness={0.7} />
                    </>}


                </ManagedEffectComposer>
            </Suspense>

        </>
    )
}

export default SceneTwo;
